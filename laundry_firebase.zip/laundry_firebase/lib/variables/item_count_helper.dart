class ProductsRemaining {
  String name;
  int count;

  ProductsRemaining(this.name, this.count);

}
