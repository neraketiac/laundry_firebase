class LoyaltyModel {}
